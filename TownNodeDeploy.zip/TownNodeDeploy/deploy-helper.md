# Setup Guide

## Step 1
Make sure your device has Docker installed. You can install it from [Docker's official website](https://www.docker.com/).

## Step 2
Run the following command in the directory where you downloaded the files:

```sh
docker-compose up -d
```

